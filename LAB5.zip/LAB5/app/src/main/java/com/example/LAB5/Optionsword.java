package com.example.LAB5;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import androidx.appcompat.app.AppCompatActivity;

public class Optionsword extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.options_word);
        RadioGroup radioGroup = (RadioGroup) findViewById(R.id.radioGroup);
        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                RadioButton checkedRadioButton = (RadioButton) findViewById(checkedId);
                String text = checkedRadioButton.getText().toString();
                Log.d("mymessage1", String.valueOf(text));
                switch (text){
                    case "Монгол үгийг ил харуулна":
                        Intent intent = new Intent(Optionsword.this, com.example.LAB5.MainActivity.class);

                        intent.putExtra("languj","1" );
                        startActivity(intent);
                        break;
                    case "Англи үгийг ил харуулна":
                        Intent intent1 = new Intent(Optionsword.this, com.example.LAB5.MainActivity.class);

                        intent1.putExtra("languj","2" );
                        startActivity(intent1);
                        break;
                    case "2ланг нь ил харуулна":
                        Intent intent2 = new Intent(Optionsword.this, com.example.LAB5.MainActivity.class);

                        intent2.putExtra("languj","3" );
                        startActivity(intent2);
                        break;
                }
                Log.d("mymessage", String.valueOf(checkedId));
            }
        });


    }
}